# A =int(input("nhap gia tri dong xu: "))
# B= int(input("nhap gia tri dong xu: "))
# C =int(input("nhap vao gia tien: "))

# if(A > B):
#     A,B = B,A
# k = 0
# h = 0
# if(C % A ==0):
#     return (C//A)
# else:   
#     n= 1
#     M = C
#     while(M-n*B> 0):
#         if((M-n*B) % A == 0):
#             k = n+ (M-n*B) // A
#             break
#         else:
#             n +=1
# if(k != 0):
#     print(k)
# elif(k == 0 and C % B == 0):
#     print(C//B)
# else:
#     print(-1)
    